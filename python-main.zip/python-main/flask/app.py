from flask import Flask, render_template

app = Flask(__name__)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/products")
def products():
    return "this is the products page"

# if __name__ == "main":
#     app.run(debug = True, port = 8000)