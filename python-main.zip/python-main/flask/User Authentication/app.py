from flask import Flask, request, render_template
from flask_sqlalchemy import SQLALchemy

app = Flask(__name__)
db = SQLALchemy(app)

class User(db.model):
    name = db.column(db.String(30), nullable = False)
    email = db.column(db.String(40), unique = True)
    password = db.column(db.String(50))

    def __init__(self, user, email, password):
        self.name = name
        self.email = email
        self.password = password


@app.route("/")
def home():
    return "hi"

@app.route("/register", methods = ["GET", "POST"])
def register():
    if request.method == "POST":
        pass
    return render_template("register.html")

@app.route("/login", methods = ["GET", "POST"])
def login():
    if request.method == "POST":
        pass
    return render_template("login.html")